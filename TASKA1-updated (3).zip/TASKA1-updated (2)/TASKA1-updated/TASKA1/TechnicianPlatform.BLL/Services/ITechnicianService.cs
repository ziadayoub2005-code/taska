using TechnicianPlatform.BLL.Models;
using TechnicianPlatform.DAL.Entities;

namespace TechnicianPlatform.BLL.Services
{
    public interface ITechnicianService
    {
        Task<PagedResult<TechnicianProfile>> GetApprovedTechniciansAsync(
            string? searchTerm,
            int? categoryId,
            double? latitude,
            double? longitude,
            int pageNumber = 1,
            int pageSize = 10);
    }
}
