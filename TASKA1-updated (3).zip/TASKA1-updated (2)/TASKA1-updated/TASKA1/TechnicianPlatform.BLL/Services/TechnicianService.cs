using Microsoft.EntityFrameworkCore;
using TechnicianPlatform.BLL.Models;
using TechnicianPlatform.DAL.Context;
using TechnicianPlatform.DAL.Entities;
using TechnicianPlatform.DAL.Enums;

namespace TechnicianPlatform.BLL.Services
{
    public class TechnicianService : ITechnicianService
    {
        private readonly ApplicationDbContext _context;

        public TechnicianService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<PagedResult<TechnicianProfile>> GetApprovedTechniciansAsync(
            string? searchTerm,
            int? categoryId,
            double? latitude,
            double? longitude,
            int pageNumber = 1,
            int pageSize = 10)
        {
            // 1. الاستعلام الأساسي مع تضمين الجداول المرتبطة
            var query = _context.TechnicianProfiles
                .Include(t => t.User)
                .Include(t => t.Category)
                .Include(t => t.Services)
                .AsQueryable();

            // 2. الفنيين الـ Approved فقط (IsApproved == true)
            query = query.Where(t => t.ApprovalStatus == ApprovalStatus.Approved);

            // 3. فلترة بالتخصص (CategoryId)
            if (categoryId.HasValue && categoryId.Value > 0)
            {
                query = query.Where(t => t.CategoryId == categoryId.Value);
            }

            // 4. البحث بالاسم (FullName) أو بالخدمة (TechnicianServices) مع منع التكرار (Distinct)
            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                searchTerm = searchTerm.Trim();
                query = query.Where(t =>
                    t.User.FullName.Contains(searchTerm) ||
                    t.DisplayName.Contains(searchTerm) ||
                    t.Services.Any(s => s.Name.Contains(searchTerm)));
            }

            // منع تكرار الفني
            query = query.Distinct();

            // 5. الترتيب بالأقرب لو الـ Latitude و Longitude متوفرين، وإلا الترتيب الافتراضي بالاسم
            if (latitude.HasValue && longitude.HasValue)
            {
                double userLat = latitude.Value;
                double userLng = longitude.Value;

                // الترتيب حسب المسافة (الأقرب أولاً، مع جعل الفنيين بدون إحداثيات في النهاية)
                query = query.OrderBy(t => t.Latitude == null || t.Longitude == null)
                             .ThenBy(t => (t.Latitude - userLat) * (t.Latitude - userLat) +
                                          (t.Longitude - userLng) * (t.Longitude - userLng));
            }
            else
            {
                // الترتيب الافتراضي بالاسم
                query = query.OrderBy(t => t.User.FullName);
            }

            // 6. تقسيم الصفحات (Pagination) باستخدام Skip و Take بحجم صفحة 10
            int totalCount = await query.CountAsync();

            if (pageNumber < 1) pageNumber = 1;
            if (pageSize < 1) pageSize = 10;

            var items = await query
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return new PagedResult<TechnicianProfile>
            {
                Items = items,
                TotalCount = totalCount,
                PageNumber = pageNumber,
                PageSize = pageSize
            };
        }
    }
}
