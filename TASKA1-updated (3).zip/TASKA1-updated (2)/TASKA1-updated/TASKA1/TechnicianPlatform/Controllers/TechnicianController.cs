using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TechnicianPlatform.BLL.Services;
using TechnicianPlatform.DAL.Context;
using TechnicianPlatform.ViewModels;

namespace TechnicianPlatform.Controllers
{
    public class TechnicianController : Controller
    {
        private readonly ITechnicianService _technicianService;
        private readonly ApplicationDbContext _context;

        public TechnicianController(ITechnicianService technicianService, ApplicationDbContext context)
        {
            _technicianService = technicianService;
            _context = context;
        }

        // GET: /Technician/Index
        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] TechnicianSearchFilterViewModel model)
        {
            // 1. جلب التخصصات المتاحة للقائمة المنسدلة
            model.Categories = await _context.ServiceCategories
                .Where(c => c.IsActive)
                .OrderBy(c => c.Name)
                .ToListAsync();

            // 2. استدعاء ميثود البحث والفلترة من طبقة الـ BLL
            model.Technicians = await _technicianService.GetApprovedTechniciansAsync(
                searchTerm: model.SearchTerm,
                categoryId: model.CategoryId,
                latitude: model.Latitude,
                longitude: model.Longitude,
                pageNumber: model.PageNumber,
                pageSize: 10
            );

            return View(model);
        }
    }
}
