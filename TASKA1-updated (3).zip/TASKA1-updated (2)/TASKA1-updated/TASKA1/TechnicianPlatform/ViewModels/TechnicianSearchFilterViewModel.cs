﻿using TechnicianPlatform.BLL.Models;
using TechnicianPlatform.DAL.Entities;

namespace TechnicianPlatform.ViewModels
{
    public class TechnicianSearchFilterViewModel
    {
        // 1. مدخلات البحث والفلترة (تم ربطها تلقائياً عبر Model Binding)
        public string? SearchTerm { get; set; }
        public int? CategoryId { get; set; }
        public double? Latitude { get; set; }
        public double? Longitude { get; set; }
        public int PageNumber { get; set; } = 1;

        // 2. قائمة التصنيفات لتعبئة القائمة المنسدلة (Dropdown)
        public List<ServiceCategory> Categories { get; set; } = new List<ServiceCategory>();

        // 3. نتائج البحث مقسمة إلى صفحات (PagedResult)
        public PagedResult<TechnicianProfile> Technicians { get; set; } = new PagedResult<TechnicianProfile>();
    }
}
